package com.adam.data.processor;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.CopyObjectRequest;
import com.amazonaws.services.s3.model.S3Event;

public class S3EventTest implements RequestHandler<S3Event, String> {


	@Override
	public String handleRequest(S3Event input, Context context) {
		  try {
		System.out.println("S3EventTest Success");
		 return null;
		  }
		  catch (Exception e) {
			  throw new RuntimeException(e);
		}
	}
}
