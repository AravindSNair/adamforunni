package com.adam.data.processor;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.S3Object;

public class AdamProjectApplication {

	public void productCsvToJson() {
		int i;
		String line = "";
		AWSCredentials credentials = new BasicAWSCredentials("AKIAIS2Z5XN3NKCE7KPQ",
				"51udOY1qcbExVEdMtIcFyXpZQ+E4i7Qc6wmJPJFD");
		AmazonS3 s3client = new AmazonS3Client(credentials);
		String bucketName = "adam-s3bucket";
		String fileName = "Chrisitiana ADAM 186 Product Code List with all details.csv";
		S3Object fetchFile = s3client.getObject(new GetObjectRequest(bucketName, fileName));
		final BufferedInputStream i1 = new BufferedInputStream(fetchFile.getObjectContent());
		InputStream objectData = fetchFile.getObjectContent();
		BufferedReader fileReader = null;
		boolean initial = true;
		ArrayList<String> header = new ArrayList<String>();
		JSONObject record = new JSONObject();
		JSONObject jsonobject = new JSONObject();
		JSONArray ja2 = new JSONArray();
		try {
			fileReader = new BufferedReader(new InputStreamReader(objectData, "UTF-8"));
			boolean substitution = false;
			while ((line = fileReader.readLine()) != null) {
				i = 0;
				String[] tokens = line.split(",");
				if (initial) {

					for (String token : tokens) {
						if (token.contains("product_substitutions")) {
							substitution = true;
						}
						header.add(token);
					}
					initial = false;
					continue;

				}
				for (String token : tokens) {
					JSONArray ja = new JSONArray();
					if (token.contains("$")) {
						JSONArray ja1 = new JSONArray();
						String token1 = token.substring(0, token.indexOf('$'));
						ja1.add(token1);
						String token2 = token.substring(token.indexOf("$") + 1, 11);
						ja1.add(token2);
						record.put(header.get(i).toString(), ja1);
						break;
					}
					record.put(header.get(i).toString(), token);

					i++;
					if (i == header.size())
						break;
				}
				ja2.add(record.toJSONString());

			}
			s3client.putObject(bucketName, "product.json", ja2.toJSONString());
			System.out.println("***********Done*************");

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
